#pragma once
#include<iostream>
#include<iomanip>
using namespace std;
/*
必须对数据有良好的组织，才能够很好的进行后面的操作
如果每次增改后都有序排列，会比较好
所以可以选用数组，或者是链表来实现
用数组，可自带排序函数
用链表则注意在初始化时进行排序
数组有其特点，列表元素不准重复
测试过erase add contains constructor
涉及到指针操作，就要重载=啊！
*/

struct Node{
	Node* next;
	int data;
	Node(int d){
		next = nullptr;
		data = d;
	}
};


class Set{
private:
	Node * head;
	int len;
	static Set *p_free;
	Set * next;

public:
	Set();
	Set( const Set& set);
	Set(int elements[], int length);
	~Set();

public:
	int size();
	void add(int element);
	bool erase(int element);
	bool contains(int element);

	friend ostream &operator<<(ostream &os,const Set &rset);

	Set& operator =(const Set& set);
	friend Set operator +(const Set &lset, const Set &rset);
	Set& operator +=(const Set &rset);
	friend Set operator -(const Set &lset, const Set &rset);
	Set& operator -=(const Set &rset);
	
	friend Set operator &(const Set &lset, const Set &rset);
	friend Set operator |(const Set &lset, const Set &rset);
	
	friend bool operator ==(const Set &lset, const Set &rset);
	friend bool operator !=(const Set &lset, const Set &rset);
	
	friend bool operator >(const Set &lset, const Set &rset);
	friend bool operator >=(const Set &lset, const Set &rset);
	friend bool operator <(const Set &lset, const Set &rset);
	friend bool operator <=(const Set &lset, const Set &rset);
	
	static void * operator new(size_t size);
	static void operator delete(void *p, size_t size); 
};

ostream &operator<<(ostream &os,const Set &rset);
Set operator +(const Set &lset, const Set &rset);
Set operator -(const Set &lset, const Set &rset);
Set operator &(const Set &lset, const Set &rset);
Set operator |(const Set &lset, const Set &rset);
bool operator ==(const Set &lset, const Set &rset);
bool operator !=(const Set &lset, const Set &rset);
bool operator >(const Set &lset, const Set &rset);
bool operator >=(const Set &lset, const Set &rset);
bool operator <(const Set &lset, const Set &rset);
bool operator <=(const Set &lset, const Set &rset);